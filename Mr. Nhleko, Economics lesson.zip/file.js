const demand = document.getElementById('demand');
const supply = document.getElementById('supply');
const eqDot = document.getElementById('eq-dot');
const explain = document.getElementById('explain-text');
const dShift = document.getElementById('demand-shift');
const sShift = document.getElementById('supply-shift');

function setScenario(){
  const d = Number(dShift.value);
  const s = Number(sShift.value);

  // base control points
  const dPath = d===0 ? "M100 80 L300 200 L500 320"
              : d===1 ? "M100 60 L300 180 L500 300"
              : "M100 100 L300 220 L500 340";
  const sPath = s===0 ? "M100 320 L300 160 L500 80"
              : s===1 ? "M100 300 L300 140 L500 60"
              : "M100 340 L300 180 L500 100";

  demand.setAttribute('d', dPath);
  supply.setAttribute('d', sPath);

  // simple estimate of intersection for visual feedback
  // intersection x ~ 300 + 30*(d - s), y ~ 200 - 30*(d - s)
  const dx = 30*(d - s);
  const cx = 300 + dx;
  const cy = 200 - dx;
  eqDot.setAttribute('cx', cx);
  eqDot.setAttribute('cy', cy);

  let txt = '';
  if(d===1 && s===0) txt = 'Demand increases → price and quantity rise.';
  else if(d===-1 && s===0) txt = 'Demand decreases → price and quantity fall.';
  else if(d===0 && s===1) txt = 'Supply increases → price falls, quantity rises.';
  else if(d===0 && s===-1) txt = 'Supply decreases → price rises, quantity falls.';
  else if(d===1 && s===-1) txt = 'Demand ↑ and Supply ↓ → price rises strongly; quantity effect ambiguous.';
  else if(d===-1 && s===1) txt = 'Demand ↓ and Supply ↑ → price falls strongly; quantity effect ambiguous.';
  else txt = 'No shifts — movement only if price changes.';
  explain.textContent = txt;
}

document.getElementById('apply').addEventListener('click', setScenario);
document.getElementById('reset').addEventListener('click', ()=>{
  dShift.value = "0"; sShift.value = "0"; setScenario();
});
setScenario();

// Quiz grading
document.getElementById('grade').addEventListener('click', ()=>{
  const form = document.getElementById('quiz-form');
  const a1 = form.q1.value, a2 = form.q2.value, a3 = form.q3.value;
  let score=0, total=3;
  if(a1==='rise') score++;
  if(a2==='price') score++;
  if(a3==='right') score++;
  document.getElementById('quiz-result').textContent = `Score: ${score}/${total}. Correct answers: 1=Rise; 2=Change in price; 3=Right (increase).`;
});
